package com.example.ex1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.text.*;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    @Override


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button reset = findViewById(R.id.Reset);
        Button submit = findViewById(R.id.Submit);
        final EditText ed = findViewById(R.id.dobF);
        ed.setFocusable(false);
        ed.setOnClickListener(new View.OnClickListener() {

            Calendar calendar = Calendar.getInstance();
            int year1 = calendar.get(Calendar.YEAR);
            int month1 = calendar.get(Calendar.MONTH);
            int dayOfMonth1 = calendar.get(Calendar.DAY_OF_MONTH);
            public void onClick(View v) {
                DatePickerDialog dp = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override

                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        SimpleDateFormat sdfo = new SimpleDateFormat("dd-MM-yyyy");
                        try{
                        Date d1 = sdfo.parse(dayOfMonth + "-" + (month + 1) + "-" + year);
                        Date d2 = sdfo.parse(dayOfMonth1 + "-" + (month1 + 1) + "-" + year1);
                        if(d1.compareTo(d2)<0) {
                            ed.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
                        }
                        else
                        {

                            Toast.makeText(MainActivity.this, "Enter a Valid date", Toast.LENGTH_SHORT).show();

                        }}catch (ParseException e)
                        {
                            Toast.makeText(MainActivity.this, "Parse Exception", Toast.LENGTH_SHORT).show();
                        }
                    }
                },year1,month1,dayOfMonth1);
                dp.show();
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               try {
                   Intent nex = new Intent(MainActivity.this, AfterSubission.class);
                   EditText ed0 = findViewById(R.id.NameF);
                   EditText ed1 = findViewById(R.id.addressF);
                   EditText ed2 = findViewById(R.id.mobileF);
                   EditText ed3 = findViewById(R.id.emailF);
                   EditText ed4 = findViewById(R.id.dobF);
                   nex.putExtra("Name", ed0.getText().toString());
                   nex.putExtra("DOB", ed4.getText().toString());
                   nex.putExtra("Address", ed1.getText().toString());
                   nex.putExtra("Email", ed3.getText().toString());
                   nex.putExtra("Mobile", ed2.getText().toString());


                   RadioGroup rg = findViewById(R.id.GenderF);
                   int r = rg.getCheckedRadioButtonId();
                   RadioButton r1 = (RadioButton) findViewById(r);
                    if(r!=-1) {
                        nex.putExtra("Gender", r1.getText().toString());
                        Toast.makeText(MainActivity.this, r1.getText().toString(), Toast.LENGTH_SHORT).show();
                    }

                   String [] s = new String[4];
                   int i =-1 ;
                   CheckBox ch = findViewById(R.id.tamil);
                   if(ch.isChecked())
                   {i++;
                       s[i] = ch.getText().toString();

                   }
                   ch = findViewById(R.id.eng);

                   if(ch.isChecked())
                   {
                       i++;
                       s[i] = ch.getText().toString();
                   }

                   ch = findViewById(R.id.hindi);
                   if(ch.isChecked())
                   {
                       i++;
                       s[i] = ch.getText().toString();

                   }
                   String ss = new String();

                   for (int j=0;j<=i;++j)
                   {
                       ss = s[j] + "  " +ss;

                   }
                   Toast.makeText(MainActivity.this, ss, Toast.LENGTH_SHORT).show();
                   nex.putExtra("Language",ss);
                   startActivity(nex);
               }catch (Exception e)
               {
                   Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
               }
            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                EditText [] ed = new EditText[10];
                EditText ed0 = findViewById(R.id.NameF);
                EditText ed1 = findViewById(R.id.addressF);
                EditText ed2 = findViewById(R.id.mobileF);
                EditText ed3 = findViewById(R.id.emailF);

                RadioButton ed4 = findViewById(R.id.male);

                RadioButton ed5 = findViewById(R.id.female);
                EditText ed9 = findViewById(R.id.dobF);
                ed0.setText("");
                ed1.setText("");
                ed2.setText("");
                ed3.setText("");
                ed9.setText("");
                ed4.setChecked(false);
                ed5.setChecked(false);
                CheckBox ed6 = findViewById(R.id.tamil);
                CheckBox ed7 = findViewById(R.id.eng);
                CheckBox ed8 = findViewById(R.id.hindi);
                ed6.setChecked(false);
                ed7.setChecked(false);
                ed8.setChecked(false);

            }
        });
    }
}
