package com.example.ex1;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AfterSubission extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_after_subission);
//        Toolbar toolbar = findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
        TextView ed0 = findViewById(R.id.Name);
        TextView ed1 = findViewById(R.id.Address);
        TextView ed2 = findViewById(R.id.Mobile);
        TextView ed3 = findViewById(R.id.Email);
        TextView ed4 = findViewById(R.id.DOB);
        TextView ed5 = findViewById(R.id.Gender);
        TextView ed6 = findViewById(R.id.Language);

        Bundle extras = getIntent().getExtras();
        try{
        if(extras !=null)
        {
            ed0.setText(extras.getString("Name"));
            ed1.setText(extras.getString("Address"));
            ed2.setText(extras.getString("Mobile"));
            ed3.setText(extras.getString("Email"));
            ed4.setText(extras.getString("DOB"));
            ed5.setText(extras.getString("Gender"));
            ed6.setText(getIntent().getStringExtra("Language"));
//            ed6.setText("asdasdasd");
            Toast.makeText(this, extras.getString("Language"), Toast.LENGTH_SHORT).show();
        }}
        catch (Exception e)
        {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

}
